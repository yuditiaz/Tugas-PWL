LPPOM MUI<footer class="main-footer">
    <div class="pull-right hidden-xs"></div>
    <strong>Copyright &copy; <?php echo date("Y") ?> Basecamp</a></strong>
</footer>